package com.bookmyshow.demo.models;

public enum Feature {
    DOLBY_ATMOS,
    IMAX,
    DOLBY_DIGITAL,
    THREED
}
