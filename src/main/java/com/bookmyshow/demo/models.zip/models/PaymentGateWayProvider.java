package com.bookmyshow.demo.models;

public enum PaymentGateWayProvider {
    PAYPAL,
    STRIPE,
    PAYTM
}
