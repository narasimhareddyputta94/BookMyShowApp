package com.bookmyshow.demo.models;

public enum PaymentStatus {
    SUCCESS,
    FAILURE,
    PENDING
}
