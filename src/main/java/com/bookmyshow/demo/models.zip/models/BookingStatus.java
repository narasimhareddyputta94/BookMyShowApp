package com.bookmyshow.demo.models;

public enum BookingStatus {
    CONFIRMED,
    CANCELLED,
    PENDING
}
