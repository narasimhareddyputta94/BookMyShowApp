package com.bookmyshow.demo.models;

public enum SeatType {
    REGULAR,
    PREMIUM,
    VIP
}
