package com.bookmyshow.demo.models;

public enum PaymentMode {
    CREDIT_CARD,
    DEBIT_CARD,
    NET_BANKING,
    UPI
}
