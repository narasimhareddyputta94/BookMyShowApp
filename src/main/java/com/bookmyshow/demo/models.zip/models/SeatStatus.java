package com.bookmyshow.demo.models;

public enum SeatStatus {
    AVAILABLE,
    BOOKED,
    RESERVED
}
